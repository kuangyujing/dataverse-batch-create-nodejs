#!/usr/bin/env bash

SUBSCRIPTION="ed070054-1009-48dd-8bc0-b9c2ee96d858"
FUNCTION_NAME="DataverseBatchCreate"
RESOURCE_GROUP="nakane_Azure"

zip -rq build/package.zip . -x '.env'

if [ ! -f build/package.zip ]; then
    echo "package.zip not created"
    exit 1
fi

az functionapp deploy \
    --subscription $SUBSCRIPTION \
    --name $FUNCTION_NAME \
    --resource-group $RESOURCE_GROUP \
    --src-path build/package.zip \
    --verbose
