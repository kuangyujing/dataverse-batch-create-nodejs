'use strict'

require('dotenv').config()
const webapi_endpoint = process.env.WEBAPI_ENDPOINT
const blob_storage_account_name = process.env.BLOB_STORAGE_ACCOUNT_NAME
const blob_storage_account_key = process.env.BLOB_STORAGE_ACCOUNT_KEY

module.exports = async (context, req) => {
    context.log('JavaScript HTTP trigger function processed a request.');
    // You can call and await an async method here
    return {
        body: "Hello, world!"
    };
}
