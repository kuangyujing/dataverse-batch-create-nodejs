# Dataverse batch on Node.js

## `az` command login

```sh
az login --use-device-code
```

## Create Function App

